package com.mycompany.trabalho_analisador_sintatico_artur_pedro_ryudi;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
/**
 *
 * @author Bebeto
 */
public class Trabalho_Analisador_Sintatico_Artur_Pedro_Ryudi {

    public static void main(String[] args) {
        Tela2 tela = new Tela2();
        tela.setVisible(true);
    }
}
